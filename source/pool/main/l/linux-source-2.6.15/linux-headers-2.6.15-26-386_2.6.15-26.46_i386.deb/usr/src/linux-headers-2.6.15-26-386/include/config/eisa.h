#define CONFIG_EISA 1
