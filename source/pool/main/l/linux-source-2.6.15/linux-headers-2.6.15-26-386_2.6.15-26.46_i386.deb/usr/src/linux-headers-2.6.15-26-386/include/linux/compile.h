/* This file is auto generated, version 1 */
/*  PREEMPT */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#1 PREEMPT Thu Aug 3 02:52:00 UTC 2006"
#define LINUX_COMPILE_TIME "02:52:00"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "terranova"
#define LINUX_COMPILE_DOMAIN "buildd"
#define LINUX_COMPILER "gcc version 4.0.3 (Ubuntu 4.0.3-1ubuntu5)"
