#define CONFIG_1GB 1
