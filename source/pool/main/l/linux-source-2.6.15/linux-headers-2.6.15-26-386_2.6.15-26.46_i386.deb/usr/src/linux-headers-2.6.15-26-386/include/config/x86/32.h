#define CONFIG_X86_32 1
