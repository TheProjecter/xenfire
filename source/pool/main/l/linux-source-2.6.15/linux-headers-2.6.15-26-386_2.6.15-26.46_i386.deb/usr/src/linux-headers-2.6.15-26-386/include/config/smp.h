#undef CONFIG_SMP
