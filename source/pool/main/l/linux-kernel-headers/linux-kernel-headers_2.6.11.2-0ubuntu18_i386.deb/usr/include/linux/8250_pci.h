int pci_siig10x_fn(struct pci_dev *dev, int enable);
int pci_siig20x_fn(struct pci_dev *dev, int enable);
